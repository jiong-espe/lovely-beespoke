# Lovely&Beespoke

Static site (HTML, CSS, JS). No build step.

## Deploy to Vercel
**Dashboard:** push this folder to GitHub, then Vercel > Add New > Project > import the repo > Deploy. Leave Framework Preset as "Other"; no build command or output directory is needed.

**CLI:** `npm i -g vercel`, then run `vercel --prod` inside this folder.

## To fill in
- Replace the [PRODUCT NAME] and [YOUR EMAIL] placeholders in index.html and add product photos in the hero.
- The email signup and "Ask Bea" boxes are front-end only; connect a form service (Formspree, Klaviyo, Mailchimp) or an API route.
